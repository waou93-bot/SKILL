# Raccordement proposé — Business Checklist 2.0

**Fourni, non appliqué.** Les routeurs présents sur les ordinateurs n’ont pas été
lus ou modifiés lors de la génération de ce package.

## Règle minimale Organisation

Lorsqu’une demande démarre un projet explicitement monétisable ou remet en cause
un choix économique important (marché, cible, prix, revenus, financement), lire
BUSINESS/ puis sélectionner `business-checklist` avant un engagement important.
Réutiliser les preuves valides et limiter la mise à jour au périmètre affecté.
Un audit demandé de l’existant ne réinitialise pas le produit.

Ne pas router une retouche, un bug ou un loisir non commercial vers ce module.
Ne pas relancer Business s’il travaille déjà sous le même run_id.

## Flux

Organisation → Business Checklist → décision et livrables → Organisation.
Business Checklist ↔ SEO uniquement pour une question d’acquisition identifiée.
Organisation → New Pro / New Site / New App selon le prochain périmètre approuvé.
Sans Organisation : utilisateur → Business Checklist → utilisateur.

TESTER prépare une expérience, pas toute la production. GO_PILOTE et
LANCER_PROGRESSIVEMENT restent bornés et n’accordent pas eux-mêmes de permissions.
BLOQUE_INFORMATION décrit l’information précise manquante ; STOP_VERSION_ACTUELLE
précise l’obstacle et les conditions qui permettraient une nouvelle version.

## Sortie

Utiliser `business-checklist/assets/05-decision-handoff.json` comme contrat 2.0.
Le valideur fourni contrôle la cohérence déclarée, pas l’authenticité des preuves.
Les décisions V1 doivent rester historiques tant qu’elles n’ont pas été réévaluées.
Une adaptation du routeur est nécessaire pour lire les nouveaux champs ; aucun
hook exécutable ou plugin n’est installé par le simple ajout de ce document.

## SEO

Partager offre, cible, prix, contribution, contraintes et objectifs.
Lire la version réellement installée de SEO, pas seulement un ancien contrat.
Récupérer intérêt économique du canal, santé technique, données et hypothèses,
coûts, calendrier et test. Éviter les doubles comptes via des IDs de coût uniques.
Sans SEO installé, signaler la limite et continuer les autres analyses.
Aucun mauvais score technique ni faible volume SEO ne suffit à condamner le projet.

## Adoption et vérification

Sauvegarder les instructions concernées ; effectuer une modification limitée,
idempotente, compatible avec les priorités locales. Vérifier cas nouveau projet,
projet existant, simple bug, absence de SEO et absence d’Organisation. Ne déclarer
l’intégration fonctionnelle qu’après observation de son chargement réel.
