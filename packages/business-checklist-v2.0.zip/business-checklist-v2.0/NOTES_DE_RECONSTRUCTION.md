# Reconstruction depuis la conversation — 16 septembre 2026

## Base effectivement utilisée

Package Business v1.0 fourni, conversation sur nouveaux projets/projets existants,
usage sur deux PC, Organisation absent, prompts desktop et skill SEO v1.0 fourni.
La V2 ajoute une checklist exploitable plutôt que de remplacer le business plan.

## Correspondance des demandes

| Demande/contrainte | Implémentation |
|---|---|
| Nouveau projet à monétiser | Mode NOUVEAU_PROJET et déclenchement ciblé |
| Web et Reddit en profondeur | Protocole contradictoire, sources datées, biais et contre-preuves |
| Attentes des investisseurs | Séparation porteur/banque/investisseur, critères adaptés au stade |
| Éviter un projet mal engagé | Six gates, tests réfutables, engagements bornés, décisions réversibles |
| Dix parties du business plan | Modèle complet conservé dans assets/04-business-plan.md |
| Données concrètes | Registre des preuves, statuts et calculs traçables |
| Checklist et pas seulement du texte | 60 contrôles, JSON et restitution Markdown |
| Projet déjà développé | État de reprise, coûts futurs, code et décisions protégés |
| Organisation absent | Mode autonome natif |
| Organisation présent | Contrat de transmission sans second routeur ni modèle fictif |
| Skill SEO | Échange ciblé et coûts partagés, sans obliger ce canal |
| Achat unique, abonnement, affiliation | Modules séparés, sans mode de paiement imposé |
| Deux PC | Méthode portable, données de projet distinctes, pas de synchronisation implicite |
| Installation desktop | Prompt utilisant le package réel et vérifiant Windows/WSL et versions |
| Installation difficile dans ce chat | Aucun faux chemin PC ni installation revendiquée |

## Changements par rapport à V1

Le nom technique devient business-checklist. Les dix rubriques et les sources de
méthode sont conservées. Les ajouts concernent surtout l’état de checklist, la
reprise, l’affiliation, le raccordement SEO, la migration et le contrôle déterministe
de la décision. Le schéma de transmission passe à 2.0 : migration non automatique.

## Vérification documentaire ciblée

Sept pages primaires ont été rouvertes : Sequoia, Strategyzer, trois pages Bpifrance
et deux pages OpenAI. Deux discussions Reddit ont été rouvertes pour leur contenu
qualitatif. Les autres références V1 sont conservées comme héritées, non réouvertes.
Voir le registre sources.json. Il ne s’agit pas d’une étude de marché de tes projets.

## Principes retenus et sources

La présentation dépend du destinataire (S10) ; les besoins initiaux doivent être
reliés aux ressources (S14) ; le seuil de rentabilité ne remplace pas la trésorerie
(S11). Les thèmes d’un dossier investisseur viennent notamment de S01, et les tests
d’hypothèses de S05. Les discussions R01/R03 offrent des objections de praticiens,
pas des preuves de rentabilité générale. Les choix techniques de packaging sont
référencés par S13/S15. Les 60 contrôles sont une construction de cette version,
non un standard externe. Aucun quota 70/30 ni pourcentage de succès n’est adopté.
