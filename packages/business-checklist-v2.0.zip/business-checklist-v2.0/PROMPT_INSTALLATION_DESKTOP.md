# Prompt d’installation locale — Business Checklist v2.0

Extraire le ZIP et ouvrir son dossier dans l’app avec accès aux fichiers locaux,
ou joindre l’archive si l’app sait réellement la lire. Coller le texte suivant.
Une app sans accès local ne peut pas installer ce package sur l’ordinateur.

```text
Installe localement le skill « Business Checklist » version 2.0 à partir du
package fourni. Écris les fichiers et vérifie le résultat ; ne te contente pas
d’un plan. Cette demande porte sur l’installation, pas sur l’audit d’un projet.

1. Lis README.md, business-checklist/SKILL.md et
   INTEGRATION_ORGANISATION_SEO.md. Utilise skill-creator ou skill-installer
   seulement si réellement disponible et pertinent. Ne recrée pas une version
   simplifiée à la place de ce package.

2. Confirme l’environnement où tes commandes s’exécutent : PC local, WSL ou
   environnement distant. Ne présente jamais une écriture dans un conteneur
   distant comme une installation sur mon PC. Si tu n’as pas accès à mon PC,
   arrête uniquement l’installation et indique la limite exacte.

3. Détecte l’hôte et son emplacement de skills officiellement reconnu.
   Pour Codex local, vérifie notamment $HOME/.agents/skills/.
   Résous HOME dans l’environnement réellement utilisé (Windows/WSL/macOS/Linux).
   Vérifie la documentation officielle actuelle en cas de doute. N’installe
   rien dans un autre profil, un autre ordinateur ou un emplacement deviné.

4. Inspecte seulement les dossiers de skills/configuration pertinents.
   Si un dépôt canonique de skills est déjà configuré, respecte son mode
   d’installation et évite une copie divergente. Ne fais ni git reset, ni
   rebase, ni push ni recherche de secrets.

5. Cherche les versions business et business-checklist existantes. Sauvegarde
   hors des répertoires scannés tout fichier que tu vas remplacer. Compare
   les personnalisations. Si business est bien la V1 de ce module, migre son
   rôle vers business-checklist et conserve l’ancienne version hors découverte,
   avec un journal. Si son identité ou les changements sont ambigus, conserve-la
   et signale le conflit ; ne supprime ni ne désactive un skill inconnu.
   La relance de l’installation ne doit créer aucun doublon.

6. Copie le dossier business-checklist COMPLET, y compris agents, assets,
   references, scripts et tests. Vérifie les empreintes du package source,
   les métadonnées et les références. Ne contourne pas une protection et
   demande uniquement l’autorisation locale ciblée nécessaire.

7. Si Organisation existe, lis ses règles réelles et propose/applique le
   raccordement limité prévu, avec sauvegarde et sans second routeur. Ne
   remplace pas ses autres règles et n’invente pas Luna/Terra/Sol/Astra comme
   identifiants de modèles. Si Organisation manque, conserve le mode autonome.
   Ne crée pas Organisation, SEO, New Pro ou New App pendant cette installation.

8. N’ajoute pas de règle globale qui lance Business sur chaque demande.
   Le déclenchement concerne les nouveaux projets monétisables ou les décisions
   économiques importantes, jamais une petite correction. Une description ne
   garantit pas l’appel systématique. Ne modifie pas AGENTS.md ou un override
   sans besoin établi dans le raccordement autorisé ; préserve leur priorité.

9. Exécute les contrôles Python fournis si Python est disponible. Sinon fais
   les contrôles lisibles et signale les tests non exécutés sans installer de
   dépendances ni d’infrastructure uniquement pour ce skill.

10. Vérifie la détection réelle dans l’hôte et l’invocation appropriée à cette
    app ; distingue fichiers copiés, validation du package, chargement dans
    l’app et tests comportementaux. Si une nouvelle session est nécessaire,
    indique-le sans prétendre avoir observé sa réussite.

Ne touche à aucun de mes codes applicatifs, MASTER, BUSINESS/, données clients,
comptes, publications, déploiements, paramètres de sécurité ou modèles par défaut.
N’installe aucun service permanent ni connecteur distant.

Termine par le chemin exact, la version, les fichiers modifiés/sauvegardes,
le statut des anciennes versions, les intégrations présentes ou absentes,
les tests réellement exécutés et la méthode de premier lancement.
N’enchaîne pas automatiquement sur l’analyse d’un projet.
```
