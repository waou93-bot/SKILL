# Business Checklist v2.0

**Benchmark contradictoire → preuves → checklist → tests → finances → business plan
→ décision sur le prochain engagement.**

Package reconstruit le 16 septembre 2026 depuis les échanges et Business v1.0.
Nom du dossier installable : `business-checklist`.
Ce package n’installe pas Organisation et ne dépend pas de sa présence.

## Contenu

- `business-checklist/SKILL.md` : cœur opérationnel, modes et garde-fous.
- `business-checklist/assets/` : plan complet en dix parties, 60 contrôles,
  brief, benchmark, preuves, tests, reprise, échange SEO et contrat JSON.
- `business-checklist/references/` : méthodes, financeurs, finances, modèles
  de revenus dont affiliation, intégrations, portabilité et sources.
- `business-checklist/scripts/` et `tests/` : contrôles de cohérence déterministes.
- `PROMPT_INSTALLATION_DESKTOP.md` : installation locale et migration encadrées.
- `INTEGRATION_ORGANISATION_SEO.md` : raccordement proposé, non appliqué.
- `NOTES_DE_RECONSTRUCTION.md` : correspondance avec la conversation.
- `VERIFICATION.md` et `VALIDATION_LOG.txt` : vérifications et limites réelles.

## Utilisation immédiate comme instructions

Demander à un agent capable de lire les fichiers :

> Lis business-checklist/SKILL.md puis applique Business Checklist à ce projet.
> Commence par le MASTER et les preuves existantes. Ne modifie pas le code.

Le dossier complet contient les références utilisées par le SKILL.md ; ne pas
copier uniquement le fichier principal pour une installation durable.

## Installation locale

Extraire l’archive dans un dossier réellement accessible par l’app desktop.
Lire puis exécuter le prompt d’installation fourni. Un chemin `/mnt/data/...`
provenant d’une conversation n’est pas un chemin local Windows.

Pour Codex local, la documentation officielle consultée décrit notamment
`$HOME/.agents/skills/business-checklist/` à portée utilisateur. Détecter le HOME
réel de l’hôte, notamment Windows/WSL, avant d’écrire. L’emplacement de configuration
CODEX_HOME est distinct et ne doit pas être confondu avec ce chemin [S13, S15].

L’invocation dépend de l’hôte : sélection @ dans ChatGPT compatible ; `/skills` ou
`$business-checklist` dans Codex CLI/IDE selon la documentation consultée. La présence
d’un dossier ne prouve pas la détection dans chaque app. Vérifier dans la session
réelle et redémarrer si nécessaire. Voir `references/sources.md` dans le skill.

## V1 déjà présente

La V2 prend le nom `business-checklist`, la V1 utilisait `business`. Ne pas laisser
un double routage involontaire. Identifier, sauvegarder et migrer l’ancienne version
seulement après comparaison de ses personnalisations ; conserver une seule version
active pour ce rôle. Ne pas supprimer de dossier homonyme inconnu.

Les anciens BUSINESS/ et décisions restent lisibles. Le contrat JSON V2 est nouveau :
ne pas remplacer des évaluations V1 par un modèle vierge ni fabriquer de nouvelles
preuves pour convertir leurs décisions.

## Avec ou sans Organisation

Organisation installé : il reste le routeur et reçoit la décision.
Absent : appel direct ; aucun blocage ni faux appel de modèle.
SEO installé : échange ciblé lorsque l’acquisition organique compte dans le modèle.
Absent : limite signalée, sans analyse SEO fictive et sans installation obligatoire.

## Sur plusieurs ordinateurs

Installer la même version du skill sur chacun. Synchroniser séparément les fichiers
du projet, notamment MASTER et BUSINESS/, par le dispositif choisi par l’utilisateur.
Ce ZIP ne synchronise pas les ordinateurs et n’emporte aucune clé ou donnée client.

## Vérifications locales

Depuis la racine du package, avec Python 3.10 ou plus récent :

```text
python business-checklist/scripts/validate_package.py
python -m unittest discover -s business-checklist/tests -v
```

Pour une sortie de projet (remplacer le chemin par le vrai dossier) :

```text
python business-checklist/scripts/check_handoff.py CHEMIN/09_HANDOFF.json --checklist CHEMIN/10_CHECKLIST.json
```

Un résultat positif du contrôleur signifie cohérence des champs contrôlés, pas
preuve de demande, authenticité des sources, autorisation réelle ni succès futur.
Aucun prévisionnel de projet n’a été chiffré pendant la création de ce package.
