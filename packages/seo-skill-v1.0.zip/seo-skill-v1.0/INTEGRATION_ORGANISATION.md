# Intégration de SEO à Organisation et Business

**Statut : patch proposé, NON APPLIQUÉ.** Les fichiers d’Organisation du PC ne sont
pas accessibles dans cette conversation. Lire leur version réelle avant fusion.

## Architecture sans boucle

    Organisation → cadrage Business (si choix économique)
                 → SEO (si recherche organique pertinente)
                 → retour des hypothèses à Business/Organisation
                 → New Site / New App / Sol (périmètre autorisé)

SEO peut intervenir DANS l’étude de Business sur les canaux. Ne pas exiger « Business
validé » avant d’évaluer SEO alors que Business attend cette analyse pour décider.
Chaque retour porte run_id/entrypoint et n’ouvre pas automatiquement un nouveau run.

## Bloc à intégrer au routeur

<!-- SEO_ROUTING:BEGIN -->
Pour les demandes de stratégie SEO, audit de référencement, pré-lancement web,
refonte/migration ou diagnostic de baisse organique, charger le skill seo lorsqu’il
est réellement disponible. Pour une nouvelle activité, évaluer sa pertinence pendant
l’analyse des canaux de Business ; ne pas imposer le SEO comme canal principal.
Pour une retouche ciblée, utiliser uniquement les contrôles pertinents. Pour un projet
privé sans enjeu de recherche web, ne pas lancer un plan SEO complet.

Lire le contexte et les dossiers BUSINESS/ et SEO/ existants. Retourner à Organisation
la décision de canal ET l’état technique, les preuves, les inconnues et le backlog.
Une recommandation n’est pas une permission de publication, suppression ou dépense.
Ne pas contourner une limite Business et ne pas condamner le produit entier parce
que le SEO est non prioritaire. Éviter les rappels circulaires entre skills.
<!-- SEO_ROUTING:END -->

Ce bloc d’instructions n’est pas un hook exécutable garanti. Son chargement et son
routage doivent être vérifiés dans l’app. Ne pas ajouter un second routeur global
si Organisation est déjà référencé par les instructions du profil.

## Handoff

Utiliser seo/assets/09-handoff.json comme modèle, puis produire un vrai objet
kind=HANDOFF. Une validation JSON ne valide ni la véracité des preuves ni l’autorité
d’une permission : le routeur doit les vérifier.

`channel_decision` : A_EVALUER, PILOTE, PRIORITAIRE, SECONDAIRE, NON_PRIORITAIRE,
BLOQUE_DONNEES. `technical_readiness` : NON_AUDITE, PARTIEL, BLOQUANT, PRET_POUR_TEST.
Conserver ces deux dimensions ; les permissions et les coûts constituent d’autres champs.

Business reçoit hypothèses d’acquisition et coûts sans doubler ses dépenses. New Site,
New App ou Sol reçoivent pages, tickets, tests d’acceptation et périmètre autorisé.
La DA est une contrainte à préserver ; une refonte complète exige un arbitrage dédié.

## Installation et absence de modules

Raccordement d’un module absent : « non disponible », jamais « exécuté ».
Organisation absent : SEO autonome. Business absent : cadrage économique provisoire,
à transmettre plus tard sans produire une copie concurrente du business plan.
Ne modifier aucun autre skill pendant l’installation sauf le petit raccordement
Organisation explicitement autorisé par le prompt fourni, avec sauvegarde.

## Réouverture

Modification de cible/langue/pays/offre, nouveau domaine/refonte, migration, incident,
changement majeur des résultats, nouveaux moyens ou nouvelle preuve de conversion.
Actualiser seulement le périmètre touché. Le délai seul ne justifie pas de refaire
le dossier complet. Aucun déclenchement récurrent n’est installé par ces instructions.
