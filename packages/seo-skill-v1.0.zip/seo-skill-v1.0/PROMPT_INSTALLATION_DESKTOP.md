# Prompt d’installation — app desktop avec accès local

Ouvrir le dossier contenant le ZIP fourni ou son extraction dans l’app. Ce prompt
installe la méthode, pas une campagne SEO. Il ne crée pas d’accès Search Console.

```text
Installe réellement le skill personnel « SEO — Benchmark, stratégie & croissance
organique » depuis le package seo-skill-v1.0 fourni ou présent dans le dossier ouvert.
Ne recrée pas une version simplifiée à la place des fichiers fournis.

1. Repère le package uniquement dans les pièces jointes accessibles ou le dossier
ouvert. S’il est absent, demande-moi ce fichier, sans prétendre le télécharger
à partir d’un chemin sandbox d’une autre conversation et sans fouiller tout le PC.
Lis README.md, seo/SKILL.md et INTEGRATION_ORGANISATION.md.

2. Détecte l’environnement actif (Windows natif/WSL/autre), HOME et le profil Codex.
Vérifie l’emplacement personnel actuellement reconnu ; la documentation officielle
indique habituellement $HOME/.agents/skills/seo/. Résous ce chemin dans le bon
système, sans confondre Windows et WSL. Consulte les instructions du skill-creator
si ce skill existe, sinon applique le format documenté.

3. Vérifie le contenu de l’archive avant extraction : pas de chemin absolu, de ../,
de lien symbolique inattendu ni d’écriture hors du dossier de destination choisi.
L’extraction ne doit écraser aucun fichier existant. Les empreintes du manifest
peuvent vérifier la cohérence du package, pas certifier une signature d’éditeur.

4. Détecte les skills seo, organisation et business réellement installés, y compris
les variantes/doublons dans les périmètres actifs. S’il existe déjà un seo, sauvegarde
avec date puis compare ; ne supprime pas ses règles utiles et ne crée pas un doublon
silencieux. N’effectue pas de migration d’un autre dépôt ou profil sans accord.

5. Copie le dossier seo COMPLET : SKILL.md, agents, references, assets, scripts et
tests. Conserve les documents racine du package à proximité de l’extraction pour
la traçabilité. N’installe aucun service, crawler permanent, abonnement ou dépendance
payante. Les scripts fournis utilisent la bibliothèque standard Python ; lis-les
avant exécution. Si Python est absent, ne prétends pas avoir exécuté les tests.

6. Si Organisation est disponible, lis sa version réelle et applique uniquement
le petit raccordement SEO proposé, dans son fichier de règles approprié, avec
sauvegarde et bloc identifié SEO_ROUTING. L’installation doit être idempotente.
Préserve Luna/Terra/Sol/Astra, les permissions et tous les autres raccordements.
Ne réécris pas Organisation ou Business. Ne crée pas de second routeur global.
Si Organisation est absent, installe SEO autonome et signale l’intégration différée.

7. Ne touche à aucun code applicatif, MASTER, backlog, robots.txt, sitemap,
domaine, compte analytique, règle de sécurité ou choix de modèle pendant cette
installation. Demande uniquement l’autorisation ciblée si le sandbox empêche une
écriture nécessaire ; ne contourne pas sa protection.

8. Vérifie les fichiers, références et métadonnées. Depuis le dossier seo, exécute
si Python est disponible :
   python scripts/validate_package.py
   python -m unittest discover -s tests -p "test_*.py" -v
N’assimile pas ces tests de fichiers aux tests du comportement de l’app.

9. Vérifie la détection du skill par l’hôte si la capacité est accessible. Propose
les cas comportementaux de tests/functional-cases.md ; distingue ceux réellement
exécutés des simples lectures. Teste notamment un audit sans Search Console, une
application privée, un raccordement absent et une réinstallation sans doublon.
Ne lance pas un audit de mes projets, ne les publie pas et ne les modifie pas.

Termine par chemin exact, version, fichiers modifiés, sauvegardes, intégrations
réelles, contrôles exécutés/non exécutés, méthode d’invocation et éventuel besoin
d’ouvrir une nouvelle conversation. Ne dis pas « installé sur mes deux PC » :
seul cet environnement est concerné.
```
