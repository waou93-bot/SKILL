# Du business plan au plan SEO : principes retenus

Recherche arrêtée au **16 septembre 2026**. Périmètre : conception d’un skill
réutilisable ; ce rapport n’est l’audit d’aucun site de l’utilisateur.
Bibliographie : [24 pages officielles et 4 discussions Reddit](seo/references/sources.md).

## 1. La question n’est pas « comment produire plus d’articles ? »

Le nouveau module doit décider si la recherche organique est un levier intéressant,
quelle place lui donner et quoi mesurer. Un petit marché peut être utile si les visites
répondent à un objectif réel ; un grand volume peut être inutile si l’offre ne correspond
pas à l’intention. C’est une logique de décision proposée pour ce skill, non un secret
algorithmique.

Google présente le SEO comme un moyen d’aider les moteurs à comprendre un contenu
et les utilisateurs à le découvrir. Son guide exclut les garanties de première place
et rappelle la variabilité des délais. La conséquence retenue est de séparer qualité
de l’exécution et validation du canal. [S01, S02]

Le dossier conserve donc deux axes : **intérêt stratégique du canal** et **état technique
du périmètre**. Un site peut être accessible mais sans stratégie de demande convaincante.
À l’inverse, un canal utile peut subir une panne réparable. Une note globale masquerait
cette distinction.

## 2. Le benchmark doit porter sur les résultats et les clients

Les concurrents commerciaux ne sont pas les seuls à occuper l’attention dans une
recherche. Le protocole proposé compare aussi des forums, répertoires, contenus,
outils ou formats présents sur les requêtes importantes. Il doit qualifier intention,
réponse déjà disponible et intérêt réel de visiter une page supplémentaire.

L’analyse de demande ne doit pas inventer des volumes. Google Trends travaille sur
des données normalisées/échantillonnées, pas un nombre absolu de clients ; les faibles
volumes ont des limites d’affichage. Les données publicitaires Keyword Planner ont
leur propre contexte, et sa concurrence ne mesure pas directement la difficulté
organique. [S23, S24]

Dans le skill, une métrique inaccessible devient NON_MESURE ; elle n’est pas remplacée
par une estimation silencieuse. La position exacte reste inconnue lorsque l’outil
ne permet pas de maîtriser moteur, pays, appareil et contexte.

## 3. Reddit : quatre enseignements à traiter comme hypothèses

### R01 — Des impressions aux résultats utiles

Un auteur r/juststart présente un récit de progression organique de son application.
Il distingue pages informatives, comparatifs et provenance des visites, en rapportant
aussi des résultats commerciaux. Le fil renvoie à son propre produit : chiffres,
attribution et causalité restent auto-déclarés. Le récit ne justifie pas de promettre
la même progression ni de privilégier systématiquement des comparatifs. [R01]

Règle retenue : mesurer chaque étape, vérifier la clarté des comparaisons et ne pas
confondre visibilité, clic et achat. Les déclarations économiques d’un auteur ne
remplacent pas les données du projet analysé.

### R02 — Construire n’assure pas d’être découvert

Dans r/startups, un auteur décrit des projets peu visités malgré leur disponibilité.
Il précise que son objectif est surtout d’obtenir quelques utilisateurs curieux,
non de bâtir une entreprise traditionnelle. Les réponses parlent de contenu et de
communautés, mais ne démontrent aucune recette d’acquisition. [R02]

Règle retenue : expliciter l’objectif et préparer le chemin de découverte avant de
produire beaucoup. Ne pas imposer un indicateur de revenu à un projet non commercial.

### R03 — Les récits sur les mises à jour se contredisent

Le fil « The quiet ones » de mars 2024 contient des personnes déclarant stabilité ou
progression et d’autres décrivant de fortes baisses malgré un contenu qu’elles jugent
soigné. Les explications avancées diffèrent. C’est un document historique et subjectif,
pas une étude causale ni une photographie du marché de septembre 2026. [R03]

Règle retenue : examiner technique, mesure, demande, pages et contexte avant de
nommer une cause. Ne pas attribuer automatiquement une baisse à l’IA ou à une sanction.
La documentation Google sur les baisses propose justement plusieurs familles de
causes à investiguer. [S09]

### R04 — Une offre incompréhensible reste un problème

Le fil r/SaaS critique les landing pages vagues et le jargon. Un commentateur évoque
un meilleur taux de clic, mais sans protocole vérifiable ; une réponse promeut un
produit. Le matériau suggère des questions de clarté, non un taux d’amélioration
reproductible ou une esthétique universelle. [R04]

Règle retenue : les briefs doivent préciser pour qui est l’offre, le résultat et
l’action utile. Ils ne doivent pas remplacer la direction artistique par un modèle
générique sous prétexte de conversion.

## 4. Un audit technique doit prouver ses constats

Les docs sur robots.txt, canonical et JavaScript justifient de contrôler plusieurs
couches distinctes : accès robot, contenu réellement rendu et signaux d’URL préférée.
Bloquer le crawl n’équivaut pas à protéger les données privées, et les canonicals
ne sont pas des ordres garantis. [S05, S06, S07]

La méthode exige URL, environnement, date, test et résultat pour chaque problème.
Sans Search Console ou données équivalentes, l’audit public reste partiel. Un test
sur un seul gabarit ne certifie pas un site entier.

Les performances sont un volet, pas la conclusion générale. Les Core Web Vitals
nécessitent un contexte de mesure ; les conditions de laboratoire et le vécu terrain
ne sont pas interchangeables. Le plan garde les améliorations UX distinctes des
affirmations documentées sur la recherche. [S08]

Pour les sites existants, l’objectif est de préserver leur valeur : inventaire des
URL, analyse avant fusion ou suppression, mapping des destinations, contrôles et
retour arrière. Les migrations et variantes linguistiques ont des règles propres
que le skill doit vérifier avant changement. [S10, S11]

## 5. Contenu : produire un apport, pas une quantité

Le cadre Google « people-first » demande d’évaluer la valeur apportée au lecteur,
l’originalité et la confiance. Les politiques anti-spam visent notamment le contenu
à grande échelle destiné à manipuler le classement ; réduire cela à « humain contre
IA » est une mauvaise simplification. [S03, S04]

Le skill impose donc à chaque brief une valeur propre et des preuves à obtenir.
Il interdit de fabriquer avis, tests produits et expérience vécue. Les données
structurées doivent rester cohérentes avec le contenu visible et les règles de
la fonctionnalité visée ; leur validité seule ne garantit pas un affichage enrichi. [S12]

La production proposée peut être une page d’offre, une documentation, un outil ou
une démonstration. Il n’existe pas dans ce package de quota obligatoire d’articles.

## 6. Actualisation IA : ni oubli, ni promesse artificielle

Google indique que ses fonctionnalités AI Overviews et AI Mode ne nécessitent pas
de fichier IA ni de balisage spécial. Cela motive l’intégration aux fondamentaux,
plutôt qu’une couche de prétendues obligations supplémentaires. [S14]

Point de fraîcheur important : l’annonce du 3 juin 2026 et l’aide Search Console
mentionnent désormais des rapports d’impressions génératives, avec une note de
mise à disposition mondiale au 31 août 2026. L’aide précise leurs dimensions et
les différences d’agrégation. Le skill doit vérifier l’accès et le volume de données,
pas annoncer que toute propriété dispose nécessairement d’un rapport exploitable. [S15, S22]

Ces vues ne doivent pas être ajoutées aux totaux qui les incluent. Autre piège signalé
par l’aide : certaines valeurs indisponibles peuvent devenir des zéros à l’export ;
le protocole doit préserver le sens original lorsque cette transformation est pertinente. [S22]

Microsoft a annoncé AI Performance dans Bing Webmaster Tools le 10 février 2026.
Ses mesures de citations et de requêtes de récupération ne représentent pas un
classement ou des ventes. [S16]

OpenAI sépare les préférences pour la recherche et l’entraînement ; le skill ne
modifie donc pas aveuglément les robots. Il peut proposer une analyse de la provenance
ChatGPT selon la FAQ éditeur et l’instrumentation disponible. [S17, S18]

## 7. Prévision et mesure : décisions proposées

Le plan financier SEO n’est pas un duplicata du bilan de Business. Il remet les
hypothèses de coût, de volumes et de conversion au dossier économique central.
La logique retenue est explicite : impressions hypothétiques → clics → sessions
éligibles → actions → contribution, avec les dénominateurs et délais appropriés.

Sans entrées, le modèle reste paramétrique. Les trois scénarios n’ont pas de
probabilités fabriquées. Un cas sans nouveau client sur la période expose la perte
possible. Le budget inclut le travail de recherche, technique, rédaction, expertise
et entretien, pas seulement un abonnement à un outil.

L’attribution est séparée de l’incrémentalité. Le plan demande des périodes comparables,
des définitions de conversion et une déduplication des événements. Les rapports
Search Console servent à la visibilité/recherche ; ils ne constituent pas à eux
seuls un compte de résultat. [S13]

## 8. Application à l’écosystème de l’utilisateur

Organisation reste le routeur. Business définit le cadre commercial ; SEO peut
y contribuer dès l’étude d’acquisition, sans attendre qu’un produit soit construit.
Le résultat revient à Organisation, puis aux skills de réalisation pour les tâches
autorisées. Un audit ciblé ne doit pas réouvrir un business plan complet.

Le skill est utilisable sans Organisation ou Business ; il signale alors ses limites.
Il ne prétend pas appeler des modèles distincts et ne crée aucune automatisation
récurrente. Le package est une méthode portable, pas un serveur ou un compte analytique.

Les docs OpenAI décrivent un dossier SKILL.md à portée utilisateur ainsi que les
métadonnées d’interface optionnelles. Le package fourni vise cette installation locale ;
ce n’est pas une extension publiée dans un catalogue ni une synchronisation multi-PC. [S20, S21]

## 9. Limites de ce travail

Il s’agit d’une recherche documentaire pour concevoir le skill. Aucun projet,
Search Console, analytics ou CMS privé n’a été consulté ; aucun résultat SEO n’a
été mesuré. Reddit fournit quatre exemples non représentatifs, pas une preuve de
l’efficacité générale du SEO. Les sources officielles expliquent les règles et
outils, pas tous les mécanismes de classement.

Les seuils, étapes et noms de décisions sont une proposition de gouvernance.
Les contrôles du package vérifient sa structure et certaines incohérences de
transmission, pas le comportement de l’app sur les deux ordinateurs. Les tests
fonctionnels de l’hôte restent à exécuter après installation.

Références [S01–S24, R01–R04] : [bibliographie complète](seo/references/sources.md).
