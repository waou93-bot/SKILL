# SEO — Benchmark, stratégie & croissance organique · v1.0

Créé le 16 septembre 2026. **Package source prêt à installer localement ; non installé
sur le PC de l’utilisateur.** Aucune modification d’Organisation/Business/projet n’a
été effectuée, aucun compte analytique connecté et aucun audit de site exécuté.

## Ce que fournit le skill

Une méthode réutilisable : recherche web et Reddit, benchmark, diagnostic de canal,
audit technique proportionné, plan SEO en dix parties, briefs de pages, mesure,
scénarios économiques et backlog. Fonctionne avec Organisation/Business ou seul.
Modes avant lancement, existant, préflight, migration, suivi et correction ciblée.
Les phases stratégiques ne sont pas imposées pour chaque petite correction.

## Installation recommandée

Dans une app desktop/Codex pouvant lire et écrire les fichiers locaux, ouvrir le
dossier extrait et utiliser [le prompt complet](PROMPT_INSTALLATION_DESKTOP.md).
L’emplacement utilisateur documenté est `$HOME/.agents/skills/seo/` ; le vérifier
dans le profil actif. Sous Windows natif cela correspond généralement à
`C:\Users\<utilisateur>\.agents\skills\seo\`. En WSL, utiliser le HOME de WSL.
Les métadonnées ne créent pas d’outil web ou de compte connecté. [S20]

Copier **tout `seo/`**, et pas seulement SKILL.md. Ne pas exécuter cette installation
dans un dossier système. Si une version existe, la comparer et la sauvegarder.
Les paramètres d’invocation implicite ne garantissent pas tous les déclenchements.
Le raccordement au routeur est [fourni séparément](INTEGRATION_ORGANISATION.md).

Sur l’autre PC, installer la même version puis vérifier sa détection. Le contexte
et les résultats de chaque projet (`MASTER/SEO/`, selon la structure réelle) sont
séparés de la méthode et doivent suivre le projet. Pas de synchronisation fournie.
Une copie isolée de SKILL.md ne contient pas les modèles ni la bibliothèque.

## Invocations

Avec Organisation :
> Organisation, utilise SEO pour ce projet. Lis le MASTER et BUSINESS/, évalue
> le canal et prépare les actions, sans modifier ni publier le site.

Seul :
> Utilise $seo pour ce projet existant. Audit d’abord, respect de la DA et des
> pages utiles ; indique les accès manquants et les trois prochaines actions.

Ciblé :
> Utilise SEO en CORRECTION_CIBLEE pour vérifier les canonicals de ce périmètre.
> Ne relance pas une stratégie complète et ne déploie rien.

La syntaxe `$seo` dépend de l’hôte ; l’invocation en langage naturel reste à vérifier
via sa sélection de skills. Redémarrer/ouvrir une nouvelle conversation si nécessaire.

## Vérification locale

Depuis `seo/`, avec Python 3.10 ou ultérieur :

    python scripts/validate_package.py
    python -m unittest discover -s tests -p "test_*.py" -v
    python scripts/check_handoff.py chemin/vers/12_HANDOFF.json

Aucun accès réseau ni dépendance tierce pour ces scripts. Le validateur de handoff
contrôle certaines incohérences de preuve/permission, pas la vérité des constats.
Les templates sont volontairement incomplets et refusés comme handoff exécutable.
Voir [la vérification effectuée](VERIFICATION.md). Tests d’hôte à effectuer dans l’app.

## Contenu du package

`seo/SKILL.md` ; `agents/openai.yaml` ; références techniques/méthodologiques et
bibliographie ; 12 modèles `assets/` ; 2 scripts de contrôle ; tests unitaires et
cas comportementaux. À la racine : recherche, installation, raccordement, vérification
et manifest de contenu. Aucun installateur automatique ni crawl de site fourni.

## Limites importantes

Sans web : recherche à compléter. Sans données privées : audit public partiel.
Pas de volumes, ventes, rangs ou conversions inventés. Pas de promesse de première
place, de revenu ou de citation IA. Pas de publication, dépense ou suivi récurrent
implicite. L’installation n’ajoute aucun droit. Les règles moteur et métriques doivent
être revérifiées au moment d’une exécution future.

Sources [S20/S21] et méthodologie : [bibliographie](seo/references/sources.md) et
[rapport de recherche](RAPPORT_RECHERCHE.md).
